Imports Microsoft.VisualBasic
Imports System.Windows.Controls


  Partial Public Class ShowCoordinatesBehavior
    Inherits UserControl
    Public Sub New()
      InitializeComponent()
    End Sub
  End Class

