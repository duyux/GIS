Imports System
Imports System.Windows
Imports System.Windows.Controls
Partial Public Class EditToolsAutoSave
	Inherits UserControl
	Public Sub New()
		InitializeComponent()
	End Sub
End Class

