Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Shapes
Imports ESRI.ArcGIS.Client

Namespace ArcGISSilverlightSDK

  ' TODO: Sample does not function.  API needs to accommodate workflow.  

  Partial Public Class EditToolsSelectionOnly
    Inherits UserControl

    Public Sub New()
      InitializeComponent()

      AddHandler TryCast(MyMap.Layers("Threat Areas"), FeatureLayer).Graphics.CollectionChanged, AddressOf Graphics_CollectionChanged
    End Sub

    Private Sub Graphics_CollectionChanged(ByVal sender As Object, ByVal e As System.Collections.Specialized.NotifyCollectionChangedEventArgs)
      Select Case e.Action
        Case System.Collections.Specialized.NotifyCollectionChangedAction.Add
          For Each item As Object In e.NewItems
            graphicAdded(TryCast(item, Graphic))
          Next item
        Case System.Collections.Specialized.NotifyCollectionChangedAction.Remove
          For Each item As Object In e.OldItems
            graphicRemoved(TryCast(item, Graphic))
          Next item
        Case System.Collections.Specialized.NotifyCollectionChangedAction.Replace, System.Collections.Specialized.NotifyCollectionChangedAction.Reset
          If e.OldItems IsNot Nothing Then
            For Each item As Object In e.OldItems
              graphicRemoved(TryCast(item, Graphic))
            Next item
          End If
          If e.NewItems IsNot Nothing Then
            For Each item As Object In e.NewItems
              graphicAdded(TryCast(item, Graphic))
            Next item
          End If
      End Select
    End Sub

    Private Sub graphicAdded(ByVal g As Graphic)
      If g IsNot Nothing Then
        AddHandler g.PropertyChanged, AddressOf g_PropertyChanged
      End If
    End Sub

    Private Sub graphicRemoved(ByVal g As Graphic)
      If g IsNot Nothing Then
        RemoveHandler g.PropertyChanged, AddressOf g_PropertyChanged
      End If
    End Sub

    Private Sub g_PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs)
      If e.PropertyName = "Geometry" Then

      End If
    End Sub

    Private Sub FeatureLayer_EndSaveEdits(ByVal sender As Object, ByVal e As ESRI.ArcGIS.Client.Tasks.EndEditEventArgs)
      TryCast(MyMap.Layers("HomelandSecurityMapServiceLayer"), ESRI.ArcGIS.Client.ArcGISDynamicMapServiceLayer).Refresh()
    End Sub

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
      Dim featureLayer As FeatureLayer = TryCast(MyMap.Layers("Threat Areas"), FeatureLayer)
      featureLayer.SaveEdits()
    End Sub
  End Class
End Namespace
