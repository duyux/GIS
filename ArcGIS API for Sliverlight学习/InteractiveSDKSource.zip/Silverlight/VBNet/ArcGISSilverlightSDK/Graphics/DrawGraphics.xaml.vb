Imports Microsoft.VisualBasic
Imports System.Windows.Controls
Imports ESRI.ArcGIS.Client
Imports ESRI.ArcGIS.Client.Symbols


Partial Public Class DrawGraphics
	Inherits UserControl
	Private MyDrawObject As Draw
	Private _activeSymbol As Symbol = Nothing

	Public Sub New()
		InitializeComponent()

		MyDrawObject = New Draw(MyMap) With
									 {
											 .LineSymbol = TryCast(LayoutRoot.Resources("DrawLineSymbol"), LineSymbol),
											 .FillSymbol = TryCast(LayoutRoot.Resources("DrawFillSymbol"), FillSymbol)
									 }

		AddHandler MyDrawObject.DrawComplete, AddressOf MyDrawObject_DrawComplete
	End Sub

	Private Sub MyToolbar_ToolbarItemClicked(ByVal sender As Object, ByVal e As ESRI.ArcGIS.Client.Toolkit.SelectedToolbarItemArgs)
		Select Case e.Index
			Case 0 ' Point
				MyDrawObject.DrawMode = DrawMode.Point
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultMarkerSymbol"), Symbol)
			Case 1 ' Polyline
				MyDrawObject.DrawMode = DrawMode.Polyline
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultLineSymbol"), Symbol)
			Case 2 ' Polygon
				MyDrawObject.DrawMode = DrawMode.Polygon
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case 3 ' Rectangle
				MyDrawObject.DrawMode = DrawMode.Rectangle
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case 4 ' Freehand
				MyDrawObject.DrawMode = DrawMode.Freehand
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultLineSymbol"), Symbol)
			Case 5 ' Arrow
				MyDrawObject.DrawMode = DrawMode.Arrow
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case 6 ' Triangle
				MyDrawObject.DrawMode = DrawMode.Triangle
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case 7 ' Circle
				MyDrawObject.DrawMode = DrawMode.Circle
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case 8 ' Ellipse
				MyDrawObject.DrawMode = DrawMode.Ellipse
				_activeSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), Symbol)
			Case Else	' Clear Graphics
				MyDrawObject.DrawMode = DrawMode.None
				Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MyGraphicsLayer"), GraphicsLayer)
				graphicsLayer.ClearGraphics()
		End Select
		MyDrawObject.IsEnabled = (MyDrawObject.DrawMode <> DrawMode.None)
	End Sub

	Private Sub MyToolbar_ToolbarIndexChanged(ByVal sender As Object, ByVal e As ESRI.ArcGIS.Client.Toolkit.SelectedToolbarItemArgs)
		StatusTextBlock.Text = e.Item.Text
	End Sub


	Private Sub MyDrawObject_DrawComplete(ByVal sender As Object, ByVal args As ESRI.ArcGIS.Client.DrawEventArgs)
		Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MyGraphicsLayer"), GraphicsLayer)
		Dim graphic As New ESRI.ArcGIS.Client.Graphic() With
				{
						.Geometry = args.Geometry,
						.Symbol = _activeSymbol
				}
		graphicsLayer.Graphics.Add(graphic)
	End Sub
	Private Sub GraphicsLayer_MouseLeftButtonUp(ByVal sender As Object, ByVal e As GraphicMouseButtonEventArgs)
		If EnableEditVerticesScaleRotate.IsChecked.Value Then
			Dim editor As Editor = TryCast(LayoutRoot.Resources("MyEditor"), Editor)
			If e.Graphic IsNot Nothing AndAlso Not (TypeOf e.Graphic.Geometry Is ESRI.ArcGIS.Client.Geometry.MapPoint) Then
				editor.EditVertices.Execute(e.Graphic)
			End If
		End If
	End Sub
End Class

