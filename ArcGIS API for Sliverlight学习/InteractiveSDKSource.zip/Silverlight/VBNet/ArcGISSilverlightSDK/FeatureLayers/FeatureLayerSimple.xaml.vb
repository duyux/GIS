Imports Microsoft.VisualBasic
Imports System.Windows.Controls


  Partial Public Class FeatureLayerSimple
    Inherits UserControl
    Public Sub New()
      InitializeComponent()
    End Sub
  End Class

