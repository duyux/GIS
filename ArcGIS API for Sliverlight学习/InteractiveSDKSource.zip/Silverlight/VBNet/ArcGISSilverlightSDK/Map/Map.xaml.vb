Imports Microsoft.VisualBasic
Imports System.Windows.Controls


  Partial Public Class Map
    Inherits UserControl
    Public Sub New()
      InitializeComponent()
    End Sub
  End Class

