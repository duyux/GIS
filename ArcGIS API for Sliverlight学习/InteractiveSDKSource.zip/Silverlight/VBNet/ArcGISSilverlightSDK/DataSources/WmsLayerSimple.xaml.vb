Imports System
Imports System.Collections.Generic
Imports System.Windows.Controls

Partial Public Class WmsLayerSimple
	Inherits UserControl
	Public Sub New()
		InitializeComponent()
	End Sub

End Class

