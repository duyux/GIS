Imports System
Imports System.Collections.Generic
Imports System.Windows.Controls
Imports ESRI.ArcGIS.Client
Imports ESRI.ArcGIS.Client.Geometry
Imports ESRI.ArcGIS.Client.Tasks
Imports ESRI.ArcGIS.Client.Toolkit.DataSources


Partial Public Class GeoRssSimple
	Inherits UserControl

	Public Sub New()
    InitializeComponent()
	End Sub
End Class

