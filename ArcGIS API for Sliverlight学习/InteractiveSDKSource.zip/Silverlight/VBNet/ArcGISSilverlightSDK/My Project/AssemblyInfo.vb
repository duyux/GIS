Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.
<Assembly: AssemblyTitle("ArcGISSilverlightSDK")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("ESRI")>
<Assembly: AssemblyProduct("ArcGISSilverlightSDK")>
<Assembly: AssemblyCopyright("Copyright � ESRI 2008")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
