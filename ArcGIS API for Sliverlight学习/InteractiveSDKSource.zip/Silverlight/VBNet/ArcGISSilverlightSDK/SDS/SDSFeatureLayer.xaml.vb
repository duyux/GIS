Imports Microsoft.VisualBasic
Imports System.Windows.Controls


  Partial Public Class SDSFeatureLayer
    Inherits UserControl
    Public Sub New()
      InitializeComponent()
    End Sub
  End Class

