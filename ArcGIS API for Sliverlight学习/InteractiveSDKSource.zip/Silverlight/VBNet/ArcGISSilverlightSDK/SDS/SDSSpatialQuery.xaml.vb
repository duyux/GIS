Imports Microsoft.VisualBasic
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports ESRI.ArcGIS.Client
Imports ESRI.ArcGIS.Client.Tasks
Imports System.Windows.Input
Imports ESRI.ArcGIS.Client.Symbols


  Partial Public Class SDSSpatialQuery
    Inherits UserControl
    Private _drawSurface As Draw
    Private _queryTask As QueryTask

    Public Sub New()
      InitializeComponent()

      _drawSurface = New Draw(MyMap) With
                     {
                         .LineSymbol = TryCast(LayoutRoot.Resources("DefaultLineSymbol"), LineSymbol),
                         .FillSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), FillSymbol)
                     }

      AddHandler _drawSurface.DrawComplete, AddressOf MyDrawSurface_DrawComplete

      _queryTask = New QueryTask("http://serverapps.esri.com/SDS/databases/Demo/dbo.USStates_Geographic")
      AddHandler _queryTask.ExecuteCompleted, AddressOf QueryTask_ExecuteCompleted
      AddHandler _queryTask.Failed, AddressOf QueryTask_Failed
    End Sub

    Private Sub esriTools_ToolbarItemClicked(ByVal sender As Object, ByVal e As ESRI.ArcGIS.Client.Toolkit.SelectedToolbarItemArgs)
      Select Case e.Index
        Case 0 ' Point
          _drawSurface.DrawMode = DrawMode.Point
        Case 1 ' Polyline
          _drawSurface.DrawMode = DrawMode.Polyline
        Case 2 ' Polygon
          _drawSurface.DrawMode = DrawMode.Polygon
        Case 3 ' Rectangle
          _drawSurface.DrawMode = DrawMode.Rectangle
        Case Else   ' Clear
          _drawSurface.DrawMode = DrawMode.None
          Dim selectionGraphicslayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)
          selectionGraphicslayer.ClearGraphics()
          QueryDetailsDataGrid.ItemsSource = Nothing
          ResultsDisplay.Visibility = Visibility.Collapsed
      End Select
      _drawSurface.IsEnabled = (_drawSurface.DrawMode <> DrawMode.None)
      StatusTextBlock.Text = e.Item.Text
    End Sub

    Private Sub MyDrawSurface_DrawComplete(ByVal sender As Object, ByVal args As ESRI.ArcGIS.Client.DrawEventArgs)
      Dim selectionGraphicslayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)
      selectionGraphicslayer.ClearGraphics()

      ' Bind data grid to query results
      Dim resultFeaturesBinding As New Binding("LastResult.Features")
      resultFeaturesBinding.Source = _queryTask
      QueryDetailsDataGrid.SetBinding(DataGrid.ItemsSourceProperty, resultFeaturesBinding)

      Dim query As Query = New ESRI.ArcGIS.Client.Tasks.Query()
      query.OutFields.AddRange(New String() {"STATE_NAME", "POP2008", "SUB_REGION"})
      query.OutSpatialReference = MyMap.SpatialReference
      query.Geometry = args.Geometry
      query.SpatialRelationship = SpatialRelationship.esriSpatialRelIntersects
      query.ReturnGeometry = True

      _queryTask.ExecuteAsync(query)
    End Sub

    Private Sub QueryTask_ExecuteCompleted(ByVal sender As Object, ByVal args As ESRI.ArcGIS.Client.Tasks.QueryEventArgs)
      Dim featureSet As FeatureSet = args.FeatureSet

      If featureSet Is Nothing OrElse featureSet.Features.Count < 1 Then
            MessageBox.Show("No features returned from query")
        Return
      End If

      Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)

      If featureSet IsNot Nothing AndAlso featureSet.Features.Count > 0 Then
        For Each feature As Graphic In featureSet.Features
          feature.Symbol = TryCast(LayoutRoot.Resources("ResultsFillSymbol"), Symbols.Symbol)
          graphicsLayer.Graphics.Insert(0, feature)
        Next feature
      End If

      ResultsDisplay.Visibility = Visibility.Visible

      _drawSurface.IsEnabled = False
    End Sub

    Private Sub QueryTask_Failed(ByVal sender As Object, ByVal args As TaskFailedEventArgs)
      MessageBox.Show("Query failed: " & args.Error.Message)
    End Sub

    Private Sub GraphicsLayer_MouseEnter(ByVal sender As Object, ByVal args As GraphicMouseEventArgs)
      QueryDetailsDataGrid.Focus()
      QueryDetailsDataGrid.SelectedItem = args.Graphic
      QueryDetailsDataGrid.CurrentColumn = QueryDetailsDataGrid.Columns(0)
      QueryDetailsDataGrid.ScrollIntoView(QueryDetailsDataGrid.SelectedItem, QueryDetailsDataGrid.Columns(0))
    End Sub

    Private Sub GraphicsLayer_MouseLeave(ByVal sender As Object, ByVal args As GraphicMouseEventArgs)
      QueryDetailsDataGrid.Focus()
      QueryDetailsDataGrid.SelectedItem = Nothing
    End Sub

    Private Sub QueryDetailsDataGrid_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
      For Each g As Graphic In e.AddedItems
        g.Select()
      Next g

      For Each g As Graphic In e.RemovedItems
        g.UnSelect()
      Next g
    End Sub

    Private Sub QueryDetailsDataGrid_LoadingRow(ByVal sender As Object, ByVal e As DataGridRowEventArgs)
      AddHandler e.Row.MouseEnter, AddressOf Row_MouseEnter
      AddHandler e.Row.MouseLeave, AddressOf Row_MouseLeave
    End Sub

    Private Sub Row_MouseEnter(ByVal sender As Object, ByVal e As MouseEventArgs)
      TryCast((CType(sender, System.Windows.FrameworkElement)).DataContext, Graphic).Select()
    End Sub

    Private Sub Row_MouseLeave(ByVal sender As Object, ByVal e As MouseEventArgs)
      Dim row As DataGridRow = TryCast(sender, DataGridRow)
      Dim g As Graphic = TryCast((CType(sender, System.Windows.FrameworkElement)).DataContext, Graphic)

      If (Not QueryDetailsDataGrid.SelectedItems.Contains(g)) Then
        g.UnSelect()
      End If
    End Sub

  End Class

