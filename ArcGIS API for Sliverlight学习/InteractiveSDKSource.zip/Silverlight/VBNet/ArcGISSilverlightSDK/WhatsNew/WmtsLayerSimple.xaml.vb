﻿Imports System.Windows.Controls

Partial Public Class WmtsLayerSimple
  Inherits UserControl
  Public Sub New()
    InitializeComponent()
  End Sub
End Class

