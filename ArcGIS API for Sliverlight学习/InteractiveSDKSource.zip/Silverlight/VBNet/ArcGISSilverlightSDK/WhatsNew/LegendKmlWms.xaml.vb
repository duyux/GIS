﻿Imports System.Windows.Controls

Partial Public Class LegendKmlWms
  Inherits UserControl
  Public Sub New()
    InitializeComponent()
  End Sub
End Class

