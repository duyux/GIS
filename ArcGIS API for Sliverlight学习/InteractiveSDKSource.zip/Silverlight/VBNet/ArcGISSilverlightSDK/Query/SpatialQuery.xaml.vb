Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Input
Imports ESRI.ArcGIS.Client
Imports ESRI.ArcGIS.Client.Symbols
Imports ESRI.ArcGIS.Client.Tasks
Imports ESRI.ArcGIS.Client.ValueConverters


    Partial Public Class SpatialQuery
        Inherits UserControl
        Private MyDrawSurface As Draw

        Public Sub New()
            InitializeComponent()

            MyDrawSurface = New Draw(MyMap) With {.LineSymbol = TryCast(LayoutRoot.Resources("DefaultLineSymbol"), SimpleLineSymbol), .FillSymbol = TryCast(LayoutRoot.Resources("DefaultFillSymbol"), FillSymbol)}
            AddHandler MyDrawSurface.DrawComplete, AddressOf MyDrawSurface_DrawComplete
        End Sub

        Private Sub esriTools_ToolbarItemClicked(ByVal sender As Object, ByVal e As ESRI.ArcGIS.Client.Toolkit.SelectedToolbarItemArgs)
            Select Case e.Index
                Case 0 ' Point
                    MyDrawSurface.DrawMode = DrawMode.Point
                Case 1 ' Polyline
                    MyDrawSurface.DrawMode = DrawMode.Polyline
                Case 2 ' Polygon
                    MyDrawSurface.DrawMode = DrawMode.Polygon
                Case 3 ' Rectangle
                    MyDrawSurface.DrawMode = DrawMode.Rectangle
                Case Else ' Clear
                    MyDrawSurface.DrawMode = DrawMode.None
                    Dim selectionGraphicslayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)
                    selectionGraphicslayer.ClearGraphics()
                    QueryDetailsDataGrid.ItemsSource = Nothing
                    ResultsDisplay.Visibility = Visibility.Collapsed
            End Select
            MyDrawSurface.IsEnabled = (MyDrawSurface.DrawMode <> DrawMode.None)
            StatusTextBlock.Text = e.Item.Text
        End Sub

        Private Sub MyDrawSurface_DrawComplete(ByVal sender As Object, ByVal args As ESRI.ArcGIS.Client.DrawEventArgs)
            Dim selectionGraphicslayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)
            selectionGraphicslayer.ClearGraphics()

            Dim queryTask As New QueryTask("http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Demographics/ESRI_Census_USA/MapServer/5")
            AddHandler queryTask.ExecuteCompleted, AddressOf QueryTask_ExecuteCompleted
            AddHandler queryTask.Failed, AddressOf QueryTask_Failed

            ' Bind data grid to query results
            Dim resultFeaturesBinding As New Binding("LastResult.Features")
            resultFeaturesBinding.Source = queryTask
            QueryDetailsDataGrid.SetBinding(DataGrid.ItemsSourceProperty, resultFeaturesBinding)
            Dim query As Query = New ESRI.ArcGIS.Client.Tasks.Query()

            ' Specify fields to return from query
            query.OutFields.AddRange(New String() {"STATE_NAME", "SUB_REGION", "STATE_FIPS", "STATE_ABBR", "POP2000", "POP2007"})
            query.Geometry = args.Geometry

            ' Return geometry with result features
            query.ReturnGeometry = True
            query.OutSpatialReference = MyMap.SpatialReference

            queryTask.ExecuteAsync(query)
        End Sub

        Private Sub QueryTask_ExecuteCompleted(ByVal sender As Object, ByVal args As ESRI.ArcGIS.Client.Tasks.QueryEventArgs)
            Dim featureSet As FeatureSet = args.FeatureSet

            If featureSet Is Nothing OrElse featureSet.Features.Count < 1 Then
            MessageBox.Show("No features returned from query")
                Return
            End If

            Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MySelectionGraphicsLayer"), GraphicsLayer)

            If featureSet IsNot Nothing AndAlso featureSet.Features.Count > 0 Then
                For Each feature As Graphic In featureSet.Features
                    feature.Symbol = TryCast(LayoutRoot.Resources("ResultsFillSymbol"), FillSymbol)
                    graphicsLayer.Graphics.Insert(0, feature)
                Next feature
                ResultsDisplay.Visibility = Visibility.Visible
            End If
            MyDrawSurface.IsEnabled = False
        End Sub

        Private Sub QueryTask_Failed(ByVal sender As Object, ByVal args As TaskFailedEventArgs)
            MessageBox.Show("Query failed: " & args.Error.ToString())
        End Sub

        Private Sub GraphicsLayer_MouseEnter(ByVal sender As Object, ByVal args As GraphicMouseEventArgs)
            QueryDetailsDataGrid.Focus()
            QueryDetailsDataGrid.SelectedItem = args.Graphic
            QueryDetailsDataGrid.CurrentColumn = QueryDetailsDataGrid.Columns(0)
            QueryDetailsDataGrid.ScrollIntoView(QueryDetailsDataGrid.SelectedItem, QueryDetailsDataGrid.Columns(0))
        End Sub

        Private Sub GraphicsLayer_MouseLeave(ByVal sender As Object, ByVal args As GraphicMouseEventArgs)
            QueryDetailsDataGrid.Focus()
            QueryDetailsDataGrid.SelectedItem = Nothing
        End Sub

        Private Sub QueryDetailsDataGrid_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
            For Each g As Graphic In e.AddedItems
                g.Select()
            Next g

            For Each g As Graphic In e.RemovedItems
                g.UnSelect()
            Next g
        End Sub

        Private Sub QueryDetailsDataGrid_LoadingRow(ByVal sender As Object, ByVal e As DataGridRowEventArgs)
            AddHandler e.Row.MouseEnter, AddressOf Row_MouseEnter
            AddHandler e.Row.MouseLeave, AddressOf Row_MouseLeave
        End Sub

        Private Sub Row_MouseEnter(ByVal sender As Object, ByVal e As MouseEventArgs)
            TryCast((CType(sender, System.Windows.FrameworkElement)).DataContext, Graphic).Select()
        End Sub

        Private Sub Row_MouseLeave(ByVal sender As Object, ByVal e As MouseEventArgs)
            Dim row As DataGridRow = TryCast(sender, DataGridRow)
            Dim g As Graphic = TryCast((CType(sender, System.Windows.FrameworkElement)).DataContext, Graphic)

            If Not QueryDetailsDataGrid.SelectedItems.Contains(g) Then
                g.UnSelect()
            End If
        End Sub
    End Class

