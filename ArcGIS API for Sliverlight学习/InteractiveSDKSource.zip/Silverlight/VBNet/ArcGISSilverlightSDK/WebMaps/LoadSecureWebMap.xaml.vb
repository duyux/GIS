﻿Imports System.Windows.Controls
Imports ESRI.ArcGIS.Client.WebMap
Imports System.Net
Imports System
Imports System.Json
Imports System.Windows

Partial Public Class LoadSecureWebMap
	Inherits UserControl
	Public Sub New()
		InitializeComponent()
	End Sub

	Private Sub LoadWebMapButton_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
		Dim webClient As New WebClient()

		Dim arcgisComTokenUrl As String = "https://www.arcgis.com/sharing/generateToken"
		arcgisComTokenUrl &= String.Format("?username={0}&password={1}&expiration={2}&TickCount={3}&client=requestip&f=json", UsernameTextBox.Text, PasswordTextBox.Password, 30, Environment.TickCount)

		AddHandler webClient.OpenReadCompleted, AddressOf wc_OpenReadCompleted

		webClient.OpenReadAsync(New Uri(arcgisComTokenUrl))
	End Sub
	Private Sub wc_OpenReadCompleted(ByVal s As Object, ByVal a As OpenReadCompletedEventArgs)
		Dim webMap As New Document()
		Dim jsonResponse As JsonValue = JsonObject.Load(a.Result)
		Dim token As String = jsonResponse("token")
		a.Result.Close()
		webMap.Token = token
		AddHandler webMap.GetMapCompleted, AddressOf webMap_GetMapCompleted
		webMap.GetMapAsync(WebMapTextBox.Text)
	End Sub

	Private Sub webMap_GetMapCompleted(ByVal sender As Object, ByVal e As GetMapCompletedEventArgs)
		If Not e.Error Is Nothing Then
			MessageBox.Show(String.Format("Unable to load webmap. {0}", e.Error.Message))
		Else
			LayoutRoot.Children.Insert(0, e.Map)
		End If
	End Sub
End Class

