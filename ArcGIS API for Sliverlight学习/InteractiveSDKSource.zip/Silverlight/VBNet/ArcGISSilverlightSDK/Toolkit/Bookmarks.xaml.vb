Imports Microsoft.VisualBasic
Imports System.Windows
Imports System.Windows.Controls


    Partial Public Class Bookmarks
        Inherits UserControl
        Public Sub New()
            InitializeComponent()
        End Sub
    End Class

