﻿Imports System.Windows.Controls
Imports ESRI.ArcGIS.Client.Toolkit.Primitives


    Partial Public Class LegendWithTemplates
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub Legend_Refreshed(ByVal sender As System.Object, ByVal e As ESRI.ArcGIS.Client.Toolkit.Legend.RefreshedEventArgs)
            If (e.LayerItem.LayerItems IsNot Nothing) Then
                For Each layerItemVM As LayerItemViewModel In e.LayerItem.LayerItems
                    If (layerItemVM.IsExpanded) Then
                        layerItemVM.IsExpanded = False
                    Else
                        e.LayerItem.IsExpanded = False
                    End If
                Next

            End If
        End Sub
    End Class

