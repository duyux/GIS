﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class WmsLayerSimple : UserControl
    {
        public WmsLayerSimple()
        {
            InitializeComponent();
        }    
    }
}
