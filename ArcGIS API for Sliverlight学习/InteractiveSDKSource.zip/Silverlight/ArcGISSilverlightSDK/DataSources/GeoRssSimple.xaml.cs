﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class GeoRssSimple : UserControl
    {
        public GeoRssSimple()
        {
            InitializeComponent();           
        }       
    }
}
