﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class DefineMapProjection : UserControl
    {
        public DefineMapProjection()
        {
            InitializeComponent();
        }
    }
}
