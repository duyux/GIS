﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Scalebar : UserControl
    {
        public Scalebar()
        {
            InitializeComponent();
        }
    }
}
