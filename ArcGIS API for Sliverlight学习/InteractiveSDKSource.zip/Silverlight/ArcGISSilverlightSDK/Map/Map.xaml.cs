﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Map : UserControl
    {
        public Map()
        {
            InitializeComponent();
        }    
    }
}
