﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
	public partial class LayerList : UserControl
    {
        public LayerList()
        {
              InitializeComponent();
        }
    }
}
