﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class LegendSimple : UserControl
    {
        public LegendSimple()
        {
            InitializeComponent();
        }
    }
}
