﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Navigation : UserControl
    {
        public Navigation()
        {
            InitializeComponent();
        }
    }
}
