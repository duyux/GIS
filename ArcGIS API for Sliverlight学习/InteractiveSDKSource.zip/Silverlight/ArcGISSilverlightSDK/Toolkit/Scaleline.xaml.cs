﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Scaleline : UserControl
    {
        public Scaleline()
        {
            InitializeComponent();
        }
    }
}
