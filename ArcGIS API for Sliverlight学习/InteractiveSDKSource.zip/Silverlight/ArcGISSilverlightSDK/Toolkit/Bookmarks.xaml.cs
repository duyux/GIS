﻿using System.Windows;
using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Bookmarks : UserControl
    {
        public Bookmarks()
        {
            InitializeComponent();
        }

    }
}
