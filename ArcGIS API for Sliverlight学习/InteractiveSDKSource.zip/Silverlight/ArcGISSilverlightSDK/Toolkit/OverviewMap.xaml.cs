﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class OverviewMap : UserControl
    {
        public OverviewMap()
        {
            InitializeComponent();     
        }
    }
}
