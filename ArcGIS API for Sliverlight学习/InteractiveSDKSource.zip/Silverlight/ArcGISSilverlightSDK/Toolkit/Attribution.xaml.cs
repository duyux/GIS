﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class Attribution : UserControl
    {
        public Attribution()
        {
            InitializeComponent();
        }
    }
}
