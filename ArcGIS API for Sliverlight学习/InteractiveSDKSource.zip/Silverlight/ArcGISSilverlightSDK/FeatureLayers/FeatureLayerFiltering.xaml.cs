﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class FeatureLayerFiltering : UserControl
    {
        public FeatureLayerFiltering()
        {
            InitializeComponent();
        }
    }
}
