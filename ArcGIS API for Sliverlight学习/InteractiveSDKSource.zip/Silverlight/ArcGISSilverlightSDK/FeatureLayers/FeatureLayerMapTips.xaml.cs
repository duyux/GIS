﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class FeatureLayerMapTips : UserControl
    {
        public FeatureLayerMapTips()
        {
            InitializeComponent();
        }
    }
}
