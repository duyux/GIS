﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class FeatureLayerSimple : UserControl
    {
        public FeatureLayerSimple()
        {
            InitializeComponent();
        }
    }
}
