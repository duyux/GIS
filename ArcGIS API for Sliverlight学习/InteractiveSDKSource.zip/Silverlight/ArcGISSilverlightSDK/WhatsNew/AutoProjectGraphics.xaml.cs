﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class AutoProjectGraphics : UserControl
    {
        public AutoProjectGraphics()
        {
            InitializeComponent();
        }
    }
}
