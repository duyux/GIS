﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class WmtsLayerSimple : UserControl
    {
        public WmtsLayerSimple()
        {
            InitializeComponent();
        }
    }
}
