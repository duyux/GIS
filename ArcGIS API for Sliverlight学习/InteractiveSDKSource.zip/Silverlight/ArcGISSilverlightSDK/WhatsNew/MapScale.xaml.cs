﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class MapScale : UserControl
    {
        public MapScale()
        {
            InitializeComponent();
        }
    }
}
