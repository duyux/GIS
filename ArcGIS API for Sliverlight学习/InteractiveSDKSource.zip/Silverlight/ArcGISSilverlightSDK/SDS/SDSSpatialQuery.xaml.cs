﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Tasks;
using ESRI.ArcGIS.Client.Symbols;
using System.Windows.Input;

namespace ArcGISSilverlightSDK
{
    public partial class SDSSpatialQuery : UserControl
    {
        private Draw _drawSurface;
        QueryTask _queryTask;

        public SDSSpatialQuery()
        {
            InitializeComponent();

            _drawSurface = new Draw(MyMap)
            {
              LineSymbol = LayoutRoot.Resources["DefaultLineSymbol"] as LineSymbol,
              FillSymbol = LayoutRoot.Resources["DefaultFillSymbol"] as FillSymbol
            };
            _drawSurface.DrawComplete += MyDrawSurface_DrawComplete;

            _queryTask = new QueryTask("http://serverapps.esri.com/SDS/databases/Demo/dbo.USStates_Geographic");
            _queryTask.ExecuteCompleted += QueryTask_ExecuteCompleted;
            _queryTask.Failed += QueryTask_Failed;
        }

        private void esriTools_ToolbarItemClicked(object sender, ESRI.ArcGIS.Client.Toolkit.SelectedToolbarItemArgs e)
        {
            switch (e.Index)
            {
                case 0: // Point
                    _drawSurface.DrawMode = DrawMode.Point;                    
                    break;
                case 1: // Polyline
                    _drawSurface.DrawMode = DrawMode.Polyline;                    
                    break;
                case 2: // Polygon
                    _drawSurface.DrawMode = DrawMode.Polygon;                   
                    break;
                case 3: // Rectangle
                    _drawSurface.DrawMode = DrawMode.Rectangle;                  
                    break;
                default: // Clear
                    _drawSurface.DrawMode = DrawMode.None;
                    GraphicsLayer selectionGraphicslayer = MyMap.Layers["MySelectionGraphicsLayer"] as GraphicsLayer;
                    selectionGraphicslayer.ClearGraphics();
                    QueryDetailsDataGrid.ItemsSource = null;
                    ResultsDisplay.Visibility = Visibility.Collapsed;
                    break;
            }
            _drawSurface.IsEnabled = (_drawSurface.DrawMode != DrawMode.None);
            StatusTextBlock.Text = e.Item.Text;
        }

        private void MyDrawSurface_DrawComplete(object sender, ESRI.ArcGIS.Client.DrawEventArgs args)
        {
            GraphicsLayer selectionGraphicslayer = MyMap.Layers["MySelectionGraphicsLayer"] as GraphicsLayer;
            selectionGraphicslayer.ClearGraphics();
                        
            // Bind data grid to query results
            Binding resultFeaturesBinding = new Binding("LastResult.Features");
            resultFeaturesBinding.Source = _queryTask;
            QueryDetailsDataGrid.SetBinding(DataGrid.ItemsSourceProperty, resultFeaturesBinding);
            
            Query query = new ESRI.ArcGIS.Client.Tasks.Query();
            query.OutFields.AddRange(new string[] { "STATE_NAME", "POP2008", "SUB_REGION" });
            query.OutSpatialReference = MyMap.SpatialReference;
            query.Geometry = args.Geometry;            
            query.SpatialRelationship = SpatialRelationship.esriSpatialRelIntersects;
            query.ReturnGeometry = true;

            _queryTask.ExecuteAsync(query);
        }

        private void QueryTask_ExecuteCompleted(object sender, ESRI.ArcGIS.Client.Tasks.QueryEventArgs args)
        {
            FeatureSet featureSet = args.FeatureSet;

            if (featureSet == null || featureSet.Features.Count < 1)
            {
                MessageBox.Show("No features returned from query");
                return;
            }

            GraphicsLayer graphicsLayer = MyMap.Layers["MySelectionGraphicsLayer"] as GraphicsLayer;

            if (featureSet != null && featureSet.Features.Count > 0)
            {
                foreach (Graphic feature in featureSet.Features)
                {
                    feature.Symbol = LayoutRoot.Resources["ResultsFillSymbol"] as Symbol;
                    graphicsLayer.Graphics.Insert(0, feature);
                }
            }

            ResultsDisplay.Visibility = Visibility.Visible;

            _drawSurface.IsEnabled = false;
        }

        private void QueryTask_Failed(object sender, TaskFailedEventArgs args)
        {
            MessageBox.Show("Query failed: " + args.Error);
        }

        private void GraphicsLayer_MouseEnter(object sender, GraphicMouseEventArgs args)
        {
            QueryDetailsDataGrid.Focus();
            QueryDetailsDataGrid.SelectedItem = args.Graphic;
            QueryDetailsDataGrid.CurrentColumn = QueryDetailsDataGrid.Columns[0];
            QueryDetailsDataGrid.ScrollIntoView(QueryDetailsDataGrid.SelectedItem, QueryDetailsDataGrid.Columns[0]);
        }

        private void GraphicsLayer_MouseLeave(object sender, GraphicMouseEventArgs args)
        {
            QueryDetailsDataGrid.Focus();
            QueryDetailsDataGrid.SelectedItem = null;
        }

        private void QueryDetailsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            foreach (Graphic g in e.AddedItems)
                g.Select();

            foreach (Graphic g in e.RemovedItems)
                g.UnSelect();
        }

        private void QueryDetailsDataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.MouseEnter += Row_MouseEnter;
            e.Row.MouseLeave += Row_MouseLeave;
        }

        void Row_MouseEnter(object sender, MouseEventArgs e)
        {
            (((System.Windows.FrameworkElement)(sender)).DataContext as Graphic).Select();
        }

        void Row_MouseLeave(object sender, MouseEventArgs e)
        {
            DataGridRow row = sender as DataGridRow;
            Graphic g = ((System.Windows.FrameworkElement)(sender)).DataContext as Graphic;

            if (!QueryDetailsDataGrid.SelectedItems.Contains(g))
                g.UnSelect();
        }
    }    
}
