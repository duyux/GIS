﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class AddGraphicsXAML : UserControl
    {
        public AddGraphicsXAML()
        {
            InitializeComponent();
        }
    }
}
