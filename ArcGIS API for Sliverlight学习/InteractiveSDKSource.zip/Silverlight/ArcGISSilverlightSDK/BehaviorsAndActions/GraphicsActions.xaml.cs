﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class GraphicsActions : UserControl
    {
        public GraphicsActions()
        {
            InitializeComponent();
        }
    }
}
