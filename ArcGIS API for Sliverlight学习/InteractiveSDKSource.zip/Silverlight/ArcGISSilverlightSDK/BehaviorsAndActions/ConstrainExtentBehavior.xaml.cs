﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class ConstrainExtentBehavior : UserControl
    {
        public ConstrainExtentBehavior()
        {
            InitializeComponent();
        }
    }
}
