﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class MaintainExtentBehavior : UserControl
    {
        public MaintainExtentBehavior()
        {
            InitializeComponent();
        }
    }
}
