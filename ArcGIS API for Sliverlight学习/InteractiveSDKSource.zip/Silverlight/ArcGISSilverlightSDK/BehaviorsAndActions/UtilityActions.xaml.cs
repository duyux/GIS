﻿using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class UtilityActions : UserControl
    {
        public UtilityActions()
        {
            InitializeComponent();
        }
    }
}
