import dark from './dark';
import light from './light';

export {
  dark,
  light
};
