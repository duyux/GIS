import Vue from 'vue';
import theme from './style/theme/theme.json';

export default new Vue({
  theme: theme[1]
});
