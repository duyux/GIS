import Vue from 'vue'
import 'isomorphic-fetch'
Vue.config.productionTip = false
