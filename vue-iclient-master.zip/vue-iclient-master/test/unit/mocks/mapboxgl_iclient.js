var supermap = require('./supermap_mapboxgl');
var mapboxgl = require('@mocks/mapboxgl').mapboxgl;
module.exports.SuperMap = require('./supermap');

mapboxgl.supermap = supermap;
