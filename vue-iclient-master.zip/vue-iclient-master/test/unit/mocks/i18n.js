function geti18n() {
  return {
    t: msg => {
      return msg;
    }
  };
}

export { geti18n };
