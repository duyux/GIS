Object.defineProperty(exports, "__esModule", {
  value: true
});

require('ant-design-vue/dist/antd.css');

require('@supermap/vue-iclient-mapboxgl/static/libs/mapboxgl/mapbox-gl-enhance.css');

require('@supermap/vue-iclient-mapboxgl/static/libs/iclient-mapboxgl/iclient-mapboxgl.min.css');

require('@supermap/vue-iclient-mapboxgl/dist/iclient-mapboxgl-vue.css');

var iclient = require('@supermap/vue-iclient-mapboxgl/dist/iclient-mapboxgl-vue');

exports.default = iclient;
