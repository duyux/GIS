# 一级标题（侧边栏会根据 1，2 级标题生成索引）

<p style="font-size: 16px; color: #5e6d82; line-height: 1.5em;">
描述（后续可提成组件）
</p>

## 二级标题

<!-- // 目前用 iframe 加载组件， 后续会直接使用组件加载 -->
<!-- <sm-iframe src="https://iclient.supermap.io/examples/component/components_webmap_vue.html"></sm-iframe> -->

<!-- // 代码使用范例 -->
<!--
```vue
<sm-web-map server-url="https://iportal.supermap.io/iportal/" map-id="801571284"></sm-web-map>
``` -->

### Attributes （参数）

<!-- 默认都左对齐 :-- -->

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
| :--- | :--- | :--- | :----- | :----- |
| 参数 | 说明 | 类型 | 可选值 | 默认值 |

### Events （事件）

| name | 说明 | 回调参数 |
| :--- | :--- | :------- |
| name | 说明 | -        |

### Method （方法）

| name | 说明 | 参数 |
| :--- | :--- | :--- |
| name | 说明 | 参数 |
