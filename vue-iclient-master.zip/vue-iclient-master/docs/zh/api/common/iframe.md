# iframe

```vue
  <sm-iframe src="https://iclient.supermap.io/"></sm-iframe>
```

### Attributes

| 参数     | 说明          | 类型   | 可选值 | 默认值 |
| :------- | :------------ | :----- | :----- | :----- |
| src | 链接地址 | string | - | - |