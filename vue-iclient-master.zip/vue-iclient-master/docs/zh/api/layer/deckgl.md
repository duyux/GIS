# DeckGL 图层

<sm-iframe src="https://iclient.supermap.io/examples/component/components_deckgl_vue.html"></sm-iframe>

```html
<sm-web-map :map-options="mapOptions" @load="mapIsLoaded">
  <sm-deckgl-layer layer-type="hexagon-layer" :options="deckglOptions"></sm-deckgl-layer>
</sm-web-map>
```

```js
<script>
  $.get('../data/deck.gl/strees_data.csv', function(csvstr) {
    // 构造数据
    var features = Papa.parse(csvstr, { skipEmptyLines: true, header: true });
    var deckglOptions = {
      data: features.data,
      props: {
        extruded: true,
        radius: 55,
        autoHighlight: true,
        upperPercentile: 99,
        coverage: 0.8,
        elevationScale: 400,
        colorRange: [
          [43, 30, 61, 255],
          [56, 60, 101, 255],
          [62, 95, 126, 255],
          [73, 131, 138, 255],
          [94, 162, 141, 255],
          [130, 187, 146, 255],
          [174, 206, 161, 255],
          [214, 222, 191, 255],
        ],
        opacity: 0.8,
        // lightSettings 光照配置参数，配置三维光照效果，
        lightSettings: {
          lightsPosition: [-122.5, 37.7, 3000, -122.2, 37.9, 3000], // 指定为`[x，y，z]`的光在平面阵列中的位置
          ambientRatio: 0.2, //光照的环境比例
          diffuseRatio: 0.5, //光的漫反射率
          specularRatio: 0.3, //光的镜面反射率
          lightsStrength: [1.0, 0.0, 2.0, 0.0], //平面阵列中指定为“[x，y]`的灯的强度。 长度应该是`2 x numberOfLights`
          numberOfLights: 4, //光照值
        },
        //如需了解其他配置详情，请查看 DeckglLayer api
        onHover: function(feature) {
          if (!popup) {
            popup = new mapboxgl.Popup({
              anchor: 'bottom',
              closeButton: false,
              offset: {
                bottom: [0, -10],
              },
            });
          }
          if (!feature.object) {
            popup.remove();
            return;
          }
          //+" "+feature.lngLat
          popup.setHTML('Point Count： ' + feature.object.points.length);
          popup.setLngLat(_this.map.unproject([feature.x, feature.y]));
          popup.addTo(_this.map);
        },
      },
      callback: {
        getPosition: function(feature) {
          if (!feature.latitude || !feature.longitude) {
            return [0, 0];
          }
          return [Number(feature.longitude), Number(feature.latitude)];
        },
      },
    };
    new Vue({
      el: '#main',
      data() {
        return {
          echartsOptions: echartsOptions,
          mapOptions: {
            container: 'map', // container id
            style: {
              version: 8,
              sources: {
                'raster-tiles': {
                  type: 'raster',
                  tiles: [
                      'https://iserver.supermap.io/iserver/services/map-china400/rest/maps/ChinaDark/zxyTileImage.png?z={z}&x={x}&y={y}',
                  ],
                  tileSize: 256,
                },
              },
              layers: [
                {
                  id: 'simple-tiles',
                  type: 'raster',
                  source: 'raster-tiles',
                  minzoom: 0,
                  maxzoom: 22,
                },
              ],
            },
            center: [-122.430844, 37.772276],
            zoom: 12,
            pitch: 60,
            bearing: 36
          },
        };
      },
      methods: {
        mapIsLoaded(e) {
          _this.map = e.map;
        },
      }
    });
  });
</script>
```

### Attributes

| 参数      | 说明                                                                                                                        | 类型   | 可选值                                                                                                                                                                                        | 默认值 |
| :-------- | :-------------------------------------------------------------------------------------------------------------------------- | :----- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----- |
| layerType | 高效率图层类型                                                                                                              | object | 'scatter-plot'高效率点图层 \| 'path-layer'（路径线图层） \| 'polygon-layer'（高效率面图层） \| 'arc-layer'（曲线图层） \| 'hexagon-layer'（ 正六边形图层） \| 'screen-grid-layer'（网格图层） | -      |
| options   | 图层可选参数，参照 [SuperMap echartsLayer API](https://iclient.supermap.io/docs/mapboxgl/mapboxgl.supermap.DeckglLayer.html) | object | -                                                                                                                                                                                             | -      |
